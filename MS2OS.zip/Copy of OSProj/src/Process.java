//import java.util.concurrent.Semaphore;


public class Process extends Thread {
	
	public int processID;
    ProcessState status=ProcessState.New;	

	
	public Process(int m) {
		processID = m;
	}
	@Override
	public void run() {
		OperatingSystem.s.runningProcess=this;
		OperatingSystem.s.runningProcess.setProcessState(OperatingSystem.s.runningProcess, ProcessState.Running);
		System.out.println("in running now :"+Thread.currentThread());
		switch(processID)
		{
		case 1:System.out.println("dakhleen 1");process1();break;
		case 2:System.out.println("dakhleen 2");process2();break;
		case 3:System.out.println("dakhleen 3");process3();break;
		case 4:System.out.println("dakhleen 4");process4();break;
		case 5:System.out.println("dakhleen 5");process5();break;
		}

	}
	
	@SuppressWarnings("deprecation")
	private void process1() {
		
		OperatingSystem.s.semPrintWait();
		OperatingSystem.s.semReadWait();
		OperatingSystem.s.semInputWait();
		System.out.println("The print semaphore in P1 is taken so expected false "+OperatingSystem.s.printSemaphore);
		//System.out.println("process 1:"+s.runningProcess.status);
		OperatingSystem.printText("Enter File Name: ");
		
	//	currentThread().suspend();
		//currentThread().resume();
//		s.semPrintPost();
//		s.semPrintWait();
	
		OperatingSystem.printText(OperatingSystem.readFile(OperatingSystem.TakeInput()));
		
		System.out.println(OperatingSystem.s.runningProcess);
		
	//	System.out.println(s.runningProcess);
		//System.out.println(s.runningProcess.status);
		OperatingSystem.s.semPrintPost();
		OperatingSystem.s.semReadPost();
		OperatingSystem.s.semInputPost();
		setProcessState(this,ProcessState.Terminated);
	
		
		}
	
	private void process2() {
		OperatingSystem.s.semPrintWait();
		OperatingSystem.s.semInputWait();
		OperatingSystem.s.semWriteWait();
		OperatingSystem.printText("Enter File Name: ");
		
		//System.out.println(s.runningProcess.status);
		String filename= OperatingSystem.TakeInput();
		
		OperatingSystem.printText("Enter Data: ");
		String data= OperatingSystem.TakeInput();
	
		OperatingSystem.writefile(filename,data);
		OperatingSystem.s.semPrintPost();
		OperatingSystem.s.semInputPost();
		OperatingSystem.s.semWritePost();
		//System.out.println(s.runningProcess.status);
		setProcessState(this,ProcessState.Terminated);
		}
	private void process3() {
		int x=0;
		OperatingSystem.s.semPrintWait();
		System.out.println(OperatingSystem.s.runningProcess);
		while (x<301)
		{ 
			OperatingSystem.printText(x+"\n");
			x++;
		}
		OperatingSystem.s.semPrintPost();
		setProcessState(this,ProcessState.Terminated);
		}
	
	private void process4() {
	OperatingSystem.s.semPrintWait();
		int x=500;
		while (x<1001)
		{
			OperatingSystem.printText(x+"\n");
			x++;
		}	
		OperatingSystem.s.semPrintPost();
		setProcessState(this,ProcessState.Terminated);
		}
	private void process5() {
		OperatingSystem.s.semPrintWait();
		OperatingSystem.s.semInputWait();
		OperatingSystem.s.semWriteWait();
		OperatingSystem.printText("Enter LowerBound: ");
		String lower= OperatingSystem.TakeInput();
		OperatingSystem.printText("Enter UpperBound: ");
		String upper= OperatingSystem.TakeInput();
		int lowernbr=Integer.parseInt(lower);
		int uppernbr=Integer.parseInt(upper);
		String data="";
		
		while (lowernbr<=uppernbr)
		{
			data+=lowernbr++ +"\n";
		}	
		OperatingSystem.writefile("P5.txt", data);
		OperatingSystem.s.semPrintPost();
		OperatingSystem.s.semInputPost();
		OperatingSystem.s.semWritePost();
		setProcessState(this,ProcessState.Terminated);
	}
	
	 public static void setProcessState(Process p, ProcessState s) {
		 p.status=s;
		 if (s == ProcessState.Terminated)
		 {
			 OperatingSystem.ProcessTable.remove(OperatingSystem.ProcessTable.indexOf(p));
		 }
	}
	 
	 public static ProcessState getProcessState(Process p) {
		 return p.status;
	}
}
