import java.util.Vector;

public class MySemaphore {
	public static Vector<Process> readyList=new Vector<Process>();
	Vector<Process> blockedprintList=new Vector<Process>();
	Vector<Process> blockedreadList=new Vector<Process>();
	Vector<Process> blockedwriteList=new Vector<Process>();
	Vector<Process> blockedInputList=new Vector<Process>();
	boolean printSemaphore=true;
	boolean readSemaphore=true;
	boolean writeSemaphore=true;
	boolean InputSemaphore=true;
	static Process runningProcess=null;

	
	@SuppressWarnings("deprecation")
	public void semPrintWait() {
		System.out.println("SemprintWait before :"+printSemaphore +" thread "+Thread.currentThread()+"   "+System.nanoTime());
		if (printSemaphore) {
			this.printSemaphore = false;
			System.out.println("IF GOA WAIT SemprintWait after :"+printSemaphore +" thread "+Thread.currentThread()+" "+System.nanoTime() );
			System.out.println("if goa wait");
		}
			else {
				System.out.println("else in wait");
				runningProcess.setProcessState(runningProcess, ProcessState.Waiting);
				blockedprintList.add(runningProcess);
//				blockedprintList.add(Thread.currentThread());
//				System.out.println("before suspend: "+Thread.currentThread());
				System.out.println("else in wait: "+blockedprintList);
				Thread.currentThread().suspend();
				System.out.println("after suspend: "+Thread.currentThread());
				System.out.println(blockedprintList);
				
			}
		
	}
	public void semPrintPost() {
		if (blockedprintList.isEmpty()) {
			printSemaphore = true;
			System.out.println("msh 3arfa aktb eh in post if");
			System.out.println(Thread.currentThread());
		}
			
			else {
			/* remove a process P from s.queue */
			/* place process P on ready list */
				System.out.println("else goa post");
				System.out.println("before"+readyList.size());
				Process removedProcess =blockedprintList.firstElement();
				blockedprintList.remove(removedProcess);
				removedProcess.setProcessState(removedProcess, ProcessState.Ready);
//				readyList.add(removedProcess);
				
				System.out.println("REMOVING from blocked");
//				//Thread removedProcess =blockedprintList.firstElement();
//				System.out.println(Thread.currentThread());
//				blockedprintList.remove(removedProcess);
				//removedProcess.setProcessState(removedProcess, ProcessState.Ready);
				readyList.add(removedProcess);
				System.out.println("after"+readyList.get(0));
			}
		
	}
	
	
	@SuppressWarnings("deprecation")
	public void semWriteWait() {
		if (writeSemaphore) {
			this.writeSemaphore = false;
		
		}
			else {
			
				runningProcess.setProcessState(runningProcess, ProcessState.Waiting);
				blockedwriteList.add(runningProcess);
//				blockedprintList.add(Thread.currentThread());
//				System.out.println("before suspend: "+Thread.currentThread());
				
				Thread.currentThread().suspend();
	
				
			}
		
	}
	
	
	
	
	public void semWritePost() {
		if (blockedwriteList.isEmpty()) {
			writeSemaphore = true;
		
		}
			
			else {
			/* remove a process P from s.queue */
			/* place process P on ready list */
		
				Process removedProcess =blockedwriteList.firstElement();
				blockedwriteList.remove(removedProcess);
				removedProcess.setProcessState(removedProcess, ProcessState.Ready);

				readyList.add(removedProcess);
		
			}
		
	}
	
///////////////////////
	
	@SuppressWarnings("deprecation")
	public void semReadWait() {
		if (readSemaphore) {
			this.readSemaphore = false;
		
		}
			else {
			
				runningProcess.setProcessState(runningProcess, ProcessState.Waiting);
				blockedreadList.add(runningProcess);
//				blockedprintList.add(Thread.currentThread());
//				System.out.println("before suspend: "+Thread.currentThread());
				
				Thread.currentThread().suspend();
	
				
			}
		
	}
	
	
	
	
	public void semReadPost() {
		if (blockedreadList.isEmpty()) {
			readSemaphore = true;
		
		}
			
			else {
			/* remove a process P from s.queue */
			/* place process P on ready list */
		
				Process removedProcess =blockedreadList.firstElement();
				blockedreadList.remove(removedProcess);
				removedProcess.setProcessState(removedProcess, ProcessState.Ready);

				readyList.add(removedProcess);
		
			}
		
	}
	
	
	//////////////////////////////////////////////////////
	
	@SuppressWarnings("deprecation")
	public void semInputWait() {
		if (InputSemaphore) {
			this.InputSemaphore = false;
		
		}
			else {
			
				runningProcess.setProcessState(runningProcess, ProcessState.Waiting);
				blockedInputList.add(runningProcess);
//				blockedprintList.add(Thread.currentThread());
//				System.out.println("before suspend: "+Thread.currentThread());
				
				Thread.currentThread().suspend();
	
				
			}
		
	}
	
	
	
	
	public void semInputPost() {
		if (blockedInputList.isEmpty()) {
			InputSemaphore = true;
		
		}
			
			else {
			/* remove a process P from s.queue */
			/* place process P on ready list */
		
				Process removedProcess =blockedInputList.firstElement();
				blockedInputList.remove(removedProcess);
				removedProcess.setProcessState(removedProcess, ProcessState.Ready);

				readyList.add(removedProcess);
		
			}
		
	}

	public static void main(String[] args) {

		

	}

}
